package com.example.abhishek.layoutexample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    TextView result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        result=(TextView)findViewById(R.id.result);
        Bundle extras=getIntent().getExtras().getBundle("data");
        if(extras!=null)
        {
            Log.d("bcjnv",extras+"");
            String first_name,last_name;
            first_name=extras.getString("first_name");
            last_name=extras.getString("last_name");

            result.setText(first_name+" "+last_name);
        }
    }
}
