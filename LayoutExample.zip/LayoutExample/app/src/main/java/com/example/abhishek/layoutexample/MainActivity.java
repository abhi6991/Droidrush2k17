package com.example.abhishek.layoutexample;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText first_name,last_name;
    Button next_btn,save_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        first_name=(EditText)findViewById(R.id.first_name);
        last_name=(EditText)findViewById(R.id.last_name);
        next_btn=(Button)findViewById(R.id.next_btn);
        save_btn=(Button)findViewById(R.id.save_btn);

        save_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),first_name.getText()+" "+last_name.getText(),Toast.LENGTH_LONG).show();
            }
        });

        next_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(getApplicationContext(),SecondActivity.class);
                Bundle b=new Bundle();
                b.putString("first_name", String.valueOf(first_name.getText()));
                b.putString("last_name", String.valueOf(last_name.getText()));
                intent.putExtra("data",b);
                startActivity(intent);
            }
        });


    }


}
